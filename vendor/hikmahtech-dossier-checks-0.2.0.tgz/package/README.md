# @hikmahtech/dossier-checks

Pure-function domain check library powering [Domain Posture](https://www.domainposture.com) —
audit-grade domain hygiene reports and a free per-domain dossier at
[domainposture.com](https://www.domainposture.com). Import these functions directly if you want
the same DNS / email-auth / TLS checks Domain Posture runs, without the hosted UI, rate limits,
or MCP server.

Zero side effects, one dependency (`whoiser`, for WHOIS only). Every check takes a domain string
and returns a discriminated-union result — no throwing, no shared state.

## Install

```bash
npm i @hikmahtech/dossier-checks
```

## Checks

| Check | What it does |
|---|---|
| `dnsCheck(domain)` | A, AAAA, NS, SOA, CAA, TXT records via Cloudflare DoH |
| `mxCheck(domain)` | MX records sorted by priority |
| `spfCheck(domain)` | SPF TXT record |
| `dmarcCheck(domain)` | DMARC TXT at `_dmarc.<domain>` |
| `dkimCheck(domain)` | Probes common DKIM selectors |
| `mtaStsCheck(domain)` | MTA-STS policy (mode, mx, max_age) |
| `tlsrptCheck(domain)` | TLS-RPT (SMTP TLS reporting) policy |
| `dnssecCheck(domain)` | DNSSEC chain-of-trust (DS, DNSKEY, AD flag) |
| `tlsCheck(domain)` | Cert subject, issuer, SANs, expiry |
| `whoisCheck(domain)` | Registrar, creation/expiry dates, registry status |
| `ctLogCheck(domain)` | Subdomain discovery via Certificate Transparency logs |
| `redirectsCheck(domain)` | HTTP redirect chain (≤10 hops) |
| `headersCheck(domain)` | HTTP security headers |
| `corsCheck(domain)` | OPTIONS preflight + Access-Control-* |
| `webSurfaceCheck(domain)` | robots.txt, sitemap.xml, home `<head>` |

`dossierCheckIds` (and the `DossierCheckId` type) enumerate the stable check ids.

## Result type

All checks return `Promise<CheckResult<T>>`:

```ts
type CheckResult<T> =
  | { status: "ok"; data: T; fetchedAt: string }
  | { status: "timeout"; ms: number }
  | { status: "not_applicable"; reason: string }
  | { status: "error"; message: string };
```

Narrow with the exported `isOk` / `isError` guards. `validateDomain(input)` returns a
`ValidateResult` for input sanitisation before a check runs.

```ts
import { spfCheck, isOk } from "@hikmahtech/dossier-checks";

const r = await spfCheck("example.com");
if (isOk(r)) console.log(r.data);
```

## Rules engine

The `rules` namespace grades an `ok` finding into a severity, using the same deterministic rules
documented at [domainposture.com/methodology/v1](https://www.domainposture.com/methodology/v1):

```ts
import { rules } from "@hikmahtech/dossier-checks";
// rules.gradeFinding, rules.RULES, rules.ALL_RULE_SLUGS
// types: Severity, Grade, GradeContext, RuleFn, RuleSlug
```

## License

MIT.
